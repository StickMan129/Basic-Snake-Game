﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SNKRX__FINAL__LW
{
    public partial class Menu : Form
    {
        string title = "SNKRX";
        string name;
        int pos = 0;
        Timer t;
        public Menu()
        {
            InitializeComponent();

            t = new Timer();
            t.Interval = 500;
            t.Tick += new EventHandler(t_Tick);
            button1_Click(null, null);
        }
        void t_Tick(object sender, EventArgs e)
        {
            if (pos < title.Length)
            {
                textBox1.AppendText(title.Substring(pos, 1));
                ++pos;
            }
            else
            {
                textBox1.Clear();
                pos = 0;
            }
        }

        public void button1_Click(object sender, EventArgs e)
        {
            pos = 0;
            textBox1.Clear();
            t.Start();
        }

        private void picPlay_MouseHover(object sender, EventArgs e)
        {
            if (true)
                picPlay.Image = Properties.Resources.play_animation;
        }

        private void picPlay_Click(object sender, EventArgs e)
        {
            name = txtName.Text;
            Game g = new Game(name);
            g.Show();
            this.Hide();
        }

        private void btnHighscores_Click(object sender, EventArgs e)
        {
            Highscores h = new Highscores();
            h.Show();
            this.Hide();
        }
    }
}
