﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SNKRX__FINAL__LW
{
    public partial class Game : Form
    {
        string name = "";
        int gold = 0;
        int score;
        int fakescore;
        int highscore;



        Random rnd = new Random();
        private List<SnakeClass> SnakeList = new List<SnakeClass>();
        private SnakeClass food = new SnakeClass();
        TheSHop s;
        

        bool goLeft, goRight, goUp, goDown;

        int maxWidth;
        int maxHeight;

        int level = 1;

        public Game(string user)
        {
            InitializeComponent();

            this.name = user;
            new GameSettings();
            StartGame();
            lblLevel.Text = "Level: 1";
        }

        private void UpdateGame(object sender, PaintEventArgs e)
        {
            //this is just a renamed paint funstion of the picturebox
            //wanted to try something new instead of making a new form for all the parts I am wanting to add to the game

            Graphics canvas = e.Graphics;

            Brush snakeColour;

            for (int i = 0; i < SnakeList.Count; i++)
            {
                if (i == 0)
                {
                    snakeColour = Brushes.DarkGreen;
                }
                else
                {
                    snakeColour = Brushes.Lime;
                }

                //this is for the snake
                canvas.FillEllipse(snakeColour, new Rectangle
                    (
                    SnakeList[i].X * GameSettings.Width,
                    SnakeList[i].Y * GameSettings.Height,
                    GameSettings.Width, GameSettings.Height  
                    ));
            }

            //this is for the food
            canvas.FillEllipse(Brushes.Yellow, new Rectangle
                    (
                    food.X * GameSettings.Width,
                    food.Y * GameSettings.Height,
                    GameSettings.Width, GameSettings.Height
                    ));
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            // setting up the direction
            if (goLeft)
            {
                GameSettings.directions = "left";
            }
            if (goRight)
            {
                GameSettings.directions = "right";
            }
            if (goUp)
            {
                GameSettings.directions = "up";
            }
            if (goDown)
            {
                GameSettings.directions = "down";
            }


            for(int i = SnakeList.Count - 1; i >= 0; i--)
            {
                // doing the -- or the ++ will allow for the loop to recognize that the snake position is moving
                // We are tracking the head, which is index 0
                if (i == 0)
                {
                    switch (GameSettings.directions)
                    {
                        case "left":
                            SnakeList[i].X--;
                            break;
                        case "right":
                            SnakeList[i].X++;
                            break;
                        case "up":
                            SnakeList[i].Y--;
                            break;
                        case "down":
                            SnakeList[i].Y++;
                            break;
                    }

                    // this is for when the snake reaches the borders, it will pop out on the other side
                    if (SnakeList[i].X < 0)
                    {
                        SnakeList[i].X = maxWidth;
                    }
                    if(SnakeList[i].X > maxWidth)
                    {
                        SnakeList[i].X = 0;
                    }
                    if (SnakeList[i].Y < 0)
                    {
                        SnakeList[i].Y = maxHeight;
                    }
                    if (SnakeList[i].Y > maxHeight)
                    {
                        SnakeList[i].Y = 0;
                    }

                    if (SnakeList[i].X == food.X && SnakeList[i].Y == food.Y)
                    {
                        EatFood();
                    }

                    //this if for the bodies of the snake, to detect collision
                    for (int j = 1; j < SnakeList.Count; j++)
                    {
                        if(SnakeList[i].X == SnakeList[j].X && SnakeList[i].Y == SnakeList[j].Y)
                        {
                            GameOver();
                        }
                    }

                    if(fakescore == 10)
                    {
           //I tried to add a powerup system, but I couldn't figure out how to resume the game after a choice has been selected in the Shop Control

                        level++;
                        if(level == 11)
                        {
                            GameTimer.Stop();
                            MessageBox.Show("Congrats You won!");
                            btnRestart.Enabled = true;
                            btnRestart.Visible = true;
                        }
                        switch (level)
                        {
                            case 2:
                                GameTimer.Interval = 90;
                                break;
                            case 3:
                                GameTimer.Interval = 80;
                                break;
                            case 4:
                                GameTimer.Interval = 70;
                                break;
                            case 5:
                                GameTimer.Interval = 60;
                                break;
                            case 6:
                                GameTimer.Interval = 50;
                                break;
                            case 7:
                                GameTimer.Interval = 40;
                                break;
                            case 8:
                                GameTimer.Interval = 30;
                                break;
                            case 9:
                                GameTimer.Interval = 20;
                                break;
                            case 10:
                                GameTimer.Interval = 10;
                                break;
                        }
                        fakescore = 0;
                    }
                    

                }
                else
                {
                    //this is for the rest of the body, so it follows the head
                    SnakeList[i].X = SnakeList[i - 1].X;
                    SnakeList[i].Y = SnakeList[i - 1].Y;
                }
            }

            // this is to refresh the picture I am using as a canvas for the snake game
            picGame.Invalidate();

            

        }

        private void Game_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                goUp = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                goDown = false;
            }
        }
        private void Game_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && GameSettings.directions != "right")
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right && GameSettings.directions != "left")
            {
                goRight = true;
            }
            if(e.KeyCode == Keys.Up && GameSettings.directions != "down")
            {
                goUp = true;
            }
            if(e.KeyCode == Keys.Down && GameSettings.directions != "up")
            {
                goDown = true;
            }
        }
        private void RestartGame()
        {
            maxWidth = picGame.Width / GameSettings.Width - 1;
            maxHeight = picGame.Height / GameSettings.Height - 1;
            SnakeList.Clear();

            SnakeClass head = new SnakeClass { X = 0, Y = 0 };
            SnakeList.Add(head);

            for ( int i = 0; i < 5; i++ )
            {
                SnakeClass body = new SnakeClass();
                SnakeList.Add(body);
            }
            food = new SnakeClass { X = rnd.Next(2, maxWidth), Y = rnd.Next(2, maxHeight)};

            GameTimer.Start();
            btnRestart.Enabled = false;
            btnRestart.Visible = false;
            btnExit.Enabled = false;
            btnExit.Visible = false;
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            RestartGame();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            string filename = @"Highscores.txt";
            string filepath = Path.GetFullPath(filename);
            using (StreamWriter file = File.AppendText(filepath))
            {
                file.WriteLine($"{name} | {highscore}".ToString());
            }

            Menu m = new Menu();
            m.Show();
            this.Close();
        }

        private void StartGame()
        {
            RestartGame();
        }

        private void EatFood()
        {
            score += 1;
            fakescore += 1;
            lblScore.Text = "Score: " + score;

            SnakeClass body = new SnakeClass
            {
                X = SnakeList[SnakeList.Count - 1].X,
                Y = SnakeList[SnakeList.Count - 1].Y
            };

            SnakeList.Add(body);
            food = new SnakeClass { X = rnd.Next(2, maxWidth), Y = rnd.Next(2, maxHeight) };

        }

        private void GameOver()
        {
            GameTimer.Stop();
            btnRestart.Enabled = true;
            btnRestart.Visible = true;
            btnExit.Enabled = true;
            btnExit.Visible = true;

            if (score > highscore)
            {
                highscore = score;
                lblHighScore.Text = "High Score: " + Environment.NewLine + highscore;
                //this is to add some 'umpf' to it
                lblHighScore.ForeColor = Color.Maroon;
                lblHighScore.TextAlign = ContentAlignment.MiddleCenter;
            }
        }

    }
}
