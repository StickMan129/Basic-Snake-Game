﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SNKRX__FINAL__LW
{
    class GameSettings
    {
        public static int Width { get; set; }
        public static int Height { get; set; }
        public static string directions;

        public GameSettings()
        {
            Width = 16;
            Height = 16;
            directions = "right";
        }
    }
}
