﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SNKRX__FINAL__LW
{
    public partial class Highscores : Form
    {
        DataTable table = new DataTable();
        public Highscores()
        {
            InitializeComponent();

            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Score", typeof(int));

            dataHighScores.DataSource = table;

            string[] data = File.ReadAllLines(@"Highscores.txt");
            string[] separatedData;

            for (int i = 0; i < data.Length; i++)
            {
                separatedData = data[i].ToString().Split('|');

                string[] row = new string[separatedData.Length];

                for (int j = 0; j < separatedData.Length; j++)
                {
                    row[j] = separatedData[j].Trim();
                }
                table.Rows.Add(row);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Menu m = new Menu();
            m.Show();
            this.Close();
        }
    }
}
