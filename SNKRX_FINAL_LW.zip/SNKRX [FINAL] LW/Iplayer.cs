﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SNKRX__FINAL__LW
{
   public interface Iplayer
    {
        int GetScore();
        void GetPoint();
        bool Alive();
        void Kill();
        int HighScore();
    }
}
