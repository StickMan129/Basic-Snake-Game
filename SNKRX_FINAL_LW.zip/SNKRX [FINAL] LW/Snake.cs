﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SNKRX__FINAL__LW
{
    public partial class Snake : UserControl, Iplayer
    {
        public Snake()
        {
            InitializeComponent();
        }

        private int score = 0;
        // this is used to keep track of the player points, so when they use them to purchase powerups, it won't deduct from their actual score
        private int point = 0;
        private int highscore = 0;
        private bool alive = true;

        public bool Alive()
        {
            return this.alive;
        }

        public void GetPoint()
        {
            this.score++;
            this.point++;
        }


        public int GetScore()
        {
            return this.point;
        }

        public int HighScore()
        {
            if (this.score > this.highscore)
            {
                this.highscore = this.score;
            }

            return this.highscore;
        }

        public void Kill()
        {
            this.alive = false;
        }
    }
}
