﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SNKRX__FINAL__LW
{
    class SnakeClass
    {
        public int X { get; set; }
        public int Y { get; set; }

        public SnakeClass()
        {
            X = 0;
            Y = 0;
        }
    }
}
