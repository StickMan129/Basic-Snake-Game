﻿
namespace SNKRX__FINAL__LW
{
    partial class TheSHop
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnResume = new System.Windows.Forms.Button();
            this.lblGold = new System.Windows.Forms.Label();
            this.lblShop = new System.Windows.Forms.Label();
            this.lblSlow = new System.Windows.Forms.Label();
            this.rbtnSlow = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtnSPeed = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnResume
            // 
            this.btnResume.BackColor = System.Drawing.Color.DimGray;
            this.btnResume.Font = new System.Drawing.Font("Castellar", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnResume.ForeColor = System.Drawing.Color.DarkGray;
            this.btnResume.Location = new System.Drawing.Point(298, 18);
            this.btnResume.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(172, 43);
            this.btnResume.TabIndex = 5;
            this.btnResume.Text = "Next Level";
            this.btnResume.UseVisualStyleBackColor = false;
            this.btnResume.Click += new System.EventHandler(this.btnReRoll_Click);
            // 
            // lblGold
            // 
            this.lblGold.AutoSize = true;
            this.lblGold.Font = new System.Drawing.Font("Castellar", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblGold.ForeColor = System.Drawing.Color.Gold;
            this.lblGold.Location = new System.Drawing.Point(205, 24);
            this.lblGold.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGold.Name = "lblGold";
            this.lblGold.Size = new System.Drawing.Size(19, 29);
            this.lblGold.TabIndex = 4;
            this.lblGold.Text = "|";
            // 
            // lblShop
            // 
            this.lblShop.AutoSize = true;
            this.lblShop.Font = new System.Drawing.Font("Castellar", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblShop.Location = new System.Drawing.Point(9, 24);
            this.lblShop.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblShop.Name = "lblShop";
            this.lblShop.Size = new System.Drawing.Size(197, 29);
            this.lblShop.TabIndex = 3;
            this.lblShop.Text = "Shop - Gold:";
            // 
            // lblSlow
            // 
            this.lblSlow.AutoSize = true;
            this.lblSlow.Location = new System.Drawing.Point(8, 119);
            this.lblSlow.Name = "lblSlow";
            this.lblSlow.Size = new System.Drawing.Size(200, 25);
            this.lblSlow.TabIndex = 6;
            this.lblSlow.Text = "Slow Down Powerup | 3";
            // 
            // rbtnSlow
            // 
            this.rbtnSlow.AutoSize = true;
            this.rbtnSlow.Location = new System.Drawing.Point(229, 124);
            this.rbtnSlow.Name = "rbtnSlow";
            this.rbtnSlow.Size = new System.Drawing.Size(21, 20);
            this.rbtnSlow.TabIndex = 7;
            this.rbtnSlow.TabStop = true;
            this.rbtnSlow.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Speed Up Powerup | 1";
            // 
            // rbtnSPeed
            // 
            this.rbtnSPeed.AutoSize = true;
            this.rbtnSPeed.Location = new System.Drawing.Point(229, 158);
            this.rbtnSPeed.Name = "rbtnSPeed";
            this.rbtnSPeed.Size = new System.Drawing.Size(21, 20);
            this.rbtnSPeed.TabIndex = 7;
            this.rbtnSPeed.TabStop = true;
            this.rbtnSPeed.UseVisualStyleBackColor = true;
            // 
            // TheSHop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Controls.Add(this.rbtnSPeed);
            this.Controls.Add(this.rbtnSlow);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSlow);
            this.Controls.Add(this.btnResume);
            this.Controls.Add(this.lblGold);
            this.Controls.Add(this.lblShop);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "TheSHop";
            this.Size = new System.Drawing.Size(502, 291);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.Label lblGold;
        private System.Windows.Forms.Label lblShop;
        private System.Windows.Forms.Label lblSlow;
        private System.Windows.Forms.RadioButton rbtnSlow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtnSPeed;
    }
}
