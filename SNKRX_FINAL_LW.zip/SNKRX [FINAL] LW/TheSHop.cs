﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SNKRX__FINAL__LW
{
    public partial class TheSHop : UserControl
    {
        int golds;

        public delegate string Powerups(string pwr);
        public Powerups powerup;

        public TheSHop(int gold)
        {
            InitializeComponent();

            if(golds < gold)
            {
                golds++;
            }
            else
                golds = gold;

            lblGold.Text = golds.ToString();
        }

        private void btnReRoll_Click(object sender, EventArgs e)
        {
            if (rbtnSPeed.Checked)
            {
                if (golds >= 1)
                {
                    golds--;
                    powerup("Speed");
                }
            }
            else if (rbtnSlow.Checked)
            {
                if (golds >= 3)
                {
                    golds -= 3;
                    powerup("Slow");
                }
            }
            else
                powerup("None");

            this.Hide();

        }
    }
}
